-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 20, 2026 at 05:57 PM
-- Server version: 10.11.14-MariaDB-0ubuntu0.24.04.1
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edext`
--

-- --------------------------------------------------------

--
-- Table structure for table `Agrupa`
--

CREATE TABLE `Agrupa` (
  `curso` varchar(255) NOT NULL,
  `categoria` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Agrupa`
--

INSERT INTO `Agrupa` (`curso`, `categoria`) VALUES
('Dalavuelta', 'Social'),
('Extensionismo Industrial', 'Industrial'),
('Inclusión Energética', 'Industrial'),
('Flor del Ceibo', 'Educativo'),
('Flor del Ceibo', 'Interdisciplinar'),
('Taller de robótica educativa.', 'Social'),
('Taller de robótica educativa.', 'Educativo'),
('Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela', 'Educativo'),
('\"Herramientas de apoyo a la enseñanza de inglés. Instalación y evaluación\"', 'Social'),
('\"Herramientas de apoyo a la enseñanza de inglés. Instalación y evaluación\"', 'Educativo'),
('MicroBit', 'Industrial'),
('MicroBit', 'Educativo');

-- --------------------------------------------------------

--
-- Table structure for table `Categoria`
--

CREATE TABLE `Categoria` (
  `nombre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Categoria`
--

INSERT INTO `Categoria` (`nombre`) VALUES
('Educativo'),
('Industrial'),
('Interdisciplinar'),
('Social');

-- --------------------------------------------------------

--
-- Table structure for table `Clasifica`
--

CREATE TABLE `Clasifica` (
  `programa` varchar(255) NOT NULL,
  `categoria` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Curso`
--

CREATE TABLE `Curso` (
  `nombre` varchar(255) NOT NULL,
  `cantidadHoras` int(11) NOT NULL,
  `creditos` int(11) NOT NULL,
  `descripcion` varchar(2000) DEFAULT NULL,
  `duracion` varchar(255) DEFAULT NULL,
  `fechaRegistro` datetime(6) NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `instituto_nombre` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Curso`
--

INSERT INTO `Curso` (`nombre`, `cantidadHoras`, `creditos`, `descripcion`, `duracion`, `fechaRegistro`, `imagen`, `url`, `instituto_nombre`) VALUES
('\"Herramientas de apoyo a la enseñanza de inglés. Instalación y evaluación\"', 60, 4, 'Se realizarán visitas a escuelas rurales participantes en un proyecto conjunto del grupo PLN y el Programa de Políticas Lingüísticas de ANEP, en el marco del cual se desarrollaron diferentes herramientas para uso de maestros que enseñan inglés con apoyo remoto de profesores especializados desde Montevideo.', '12 semanas', '2026-05-24 00:00:00.000000', NULL, 'https://eva.fing.edu.uy/mod/folder/view.php?id=89398', 'INCO'),
('Dalavuelta', 60, 4, 'Dalavuelta es un proyecto de extensión que nace en el Instituto de Ingeniería Mecánica y Producción Industrial (IIMPI) de Fing, que, si bien inicia su trabajo en el desarrollo de bicicletas accesibles para personas en situación de discapacidad motriz a partir de bicicletas abandonadas, se propuso diseñar otras herramientas para fomentar la accesibilidad.', '10 semanas', '2024-06-25 00:00:00.000000', 'Curso.Dalavuelta.png', 'https://eva.fing.edu.uy/course/view.php?id=783#section-2', 'IMPII'),
('Extensionismo Industrial', 75, 5, 'El proyecto tiene como objetivo desarrollar intervenciones curriculares en pequeños emprendimientos productivos de diferentes sectores de la industria nacional. La metodología de trabajo permite articular diversas intervenciones, combinando actividades de enseñanza, extensión e investigación por parte de docentes del IMPII.', '12 semanas', '2025-06-16 00:00:00.000000', NULL, 'https://eva.fing.edu.uy/course/view.php?id=783#section-2', 'IMPII'),
('Flor del Ceibo', 150, 10, 'Flor de Ceibo es un proyecto central de la Universidad de la República, que tiene misión por movilizar la participación de estudiantes universitarios en diversas tareas vinculadas con la puesta en funcionamiento del Plan Ceibal en el territorio nacional.', '15 semanas', '2008-07-27 00:00:00.000000', 'Curso.Flor del Ceibo.png', 'http://www.flordeceibo.edu.uy/', 'DISI'),
('Inclusión Energética', 45, 3, 'En el proyecto se conjuga el trabajo de docentes y estudiantes de la carrera Ingeniería Industrial Mecánica a través del Módulo de Extensión, en donde se trabaja en el diseño, construcción y prueba de un prototipo de colector solar adquiriendo conocimientos relevantes para luego poder replicarlos junto a las familias en los talleres. Las premisas fundamentales a la hora de pensar los diseños son: por un lado el bajo costo de los materiales y por otro la fácil construcción de forma de poder construirlos ellos mismos.', '6 semanas', '2026-02-01 00:00:00.000000', 'Curso.Inclusión Energética.jpg', 'https://eva.fing.edu.uy/course/view.php?id=783#section-2', 'IMPII'),
('MicroBit', 105, 7, 'El Centro Ceibal se encuentra distribuyendo placas micro:bit (https://microbit.ceibal.edu.uy/) para que estudiantes de primaria y secundaria aprendan nociones básicas de robótica, electrónica y programación de forma autónoma y lúdica. Estas placas se basan en un microcontrolador y cuentan con leds, botones, acelerómetro, brújula, bluetooth y otros sensores. Además, las placas se programan fácilmente con lenguaje tipo \"scratch\" y python, por lo que son muy útiles para un primer acercamiento a la temática.', '15 semanas', '2026-03-13 00:00:00.000000', 'Curso.MicroBit.jpg', 'https://www.fing.edu.uy/noticias/extension/modulo-de-tallerextension-microbit', 'Eléctrica'),
('Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela', 45, 3, 'Se propone desarrollar una aplicación interactiva para tablet Android basada en el juego de tablero Komikan (versión web del juego https://codepen.io/Borborem/full/OvZBvZ/), que incluya los distintos aspectos concernientes al juego, así como a situaciones específicas particulares.', '9 semanas', '2026-06-15 00:00:00.000000', 'Curso.Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela.png', 'https://eva.fing.edu.uy/mod/folder/view.php?id=89398', 'INCO'),
('Seminarios de Resolución de Problemas', 30, 2, 'Seminario, todos los jueves en Facultad de Ingeniería a partir del jueves 25 de Julio, en las áreas en que se desarrollan los problemas de las Olimpíadas de Matemática.', '5 semanas', '2026-07-12 00:00:00.000000', NULL, 'www.tmu.edu.uy', 'IMERL'),
('Taller de robótica educativa.', 90, 6, 'La asignatura se organiza en dos etapas. La primer etapa se dicta a través de clases teórico-prácticas, donde se espera además que cada estudiante le dedique horas de estudio. La segunda etapa consiste en que los estudiantes trabajen en grupo sobre el diseño e implementación de una experiencia didáctica de inclusión del robot Butiá en el aula, utilizando los conocimientos aprendidos en clase.', '8 semanas', '2024-02-02 00:00:00.000000', 'Curso.Taller de robótica educativa.jpg', 'https://eva.fing.edu.uy/course/view.php?id=1187', 'INCO'),
('Talleres plenarios', 15, 1, 'Talleres plenarios: presentados por cuatro reconocidos matemáticos uruguayos, plantearán diversos tópicos de matemática en el marco de los cuales se realizarán actividades fomentando la integración entre estudiantes, docentes e investigadores.', '3 semanas', '2026-02-01 00:00:00.000000', NULL, 'www.tmu.edu.uy', 'IMERL');

-- --------------------------------------------------------

--
-- Table structure for table `Edicion`
--

CREATE TABLE `Edicion` (
  `nombre` varchar(255) NOT NULL,
  `cupo` int(11) DEFAULT NULL,
  `fechaFin` date NOT NULL,
  `fechaInicio` date NOT NULL,
  `fechaPublicacion` date NOT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `curso` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Edicion`
--

INSERT INTO `Edicion` (`nombre`, `cupo`, `fechaFin`, `fechaInicio`, `fechaPublicacion`, `imagen`, `curso`) VALUES
('Dalavuelta - 2025', 15, '2024-11-10', '2024-08-20', '2024-07-20', 'Edicion.Dalavuelta - 2025.jpeg', 'Dalavuelta'),
('Extensionismo Industrial - 2025', 15, '2025-11-10', '2025-08-10', '2025-07-08', NULL, 'Extensionismo Industrial'),
('Flor del Ceibo - 2010', -1, '2010-07-07', '2010-03-15', '2010-02-16', 'Edicion.Flor del Ceibo - 2010.jpeg', 'Flor del Ceibo'),
('Flor del Ceibo - 2012', -1, '2012-11-20', '2012-08-01', '2012-07-10', 'Edicion.Flor del Ceibo - 2012.jpg', 'Flor del Ceibo'),
('Flor del Ceibo - 2025', -1, '2025-08-07', '2025-04-10', '2025-03-06', 'Edicion.Flor del Ceibo - 2025.jpeg', 'Flor del Ceibo'),
('Herramientas de apoyo a la enseñanza de inglés. Instalación y evaluación - 26', 5, '2026-12-15', '2026-09-15', '2026-06-02', NULL, '\"Herramientas de apoyo a la enseñanza de inglés. Instalación y evaluación\"'),
('Inclusión Energética - 2026', 30, '2026-04-30', '2026-03-15', '2026-02-20', NULL, 'Inclusión Energética'),
('MicroBit - 2026', 30, '2026-12-05', '2026-08-12', '2026-07-02', NULL, 'MicroBit'),
('Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela - 2026', 5, '2026-10-07', '2026-07-29', '2026-07-10', NULL, 'Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela'),
('Seminarios de Resolución de Problemas - 2026', -1, '2026-10-20', '2026-09-10', '2026-07-12', NULL, 'Seminarios de Resolución de Problemas'),
('Taller de robótica educativa - 2024', 10, '2024-05-10', '2024-03-10', '2024-02-15', 'Edicion.Taller de robótica educativa - 2024.jpeg', 'Taller de robótica educativa.'),
('Taller de robótica educativa - 2026', 10, '2026-05-10', '2026-03-10', '2026-02-15', 'Edicion.Taller de robótica educativa - 2026.jpeg', 'Taller de robótica educativa.'),
('Taller de robótica educativa - 2026-2', 20, '2026-11-08', '2026-09-10', '2026-08-15', 'Edicion.Taller de robótica educativa - 2026-2.jpeg', 'Taller de robótica educativa.'),
('Talleres plenarios - 2026', -1, '2026-03-30', '2026-03-10', '2026-03-02', NULL, 'Talleres plenarios');

-- --------------------------------------------------------

--
-- Table structure for table `InscripcionEdicion`
--

CREATE TABLE `InscripcionEdicion` (
  `estado` int(11) NOT NULL,
  `fechaInscripcion` date NOT NULL,
  `edicion_nombre` varchar(255) NOT NULL,
  `estudiante_nickname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `InscripcionEdicion`
--

INSERT INTO `InscripcionEdicion` (`estado`, `fechaInscripcion`, `edicion_nombre`, `estudiante_nickname`) VALUES
(2, '2024-07-25', 'Dalavuelta - 2025', 'chechi'),
(2, '2024-08-10', 'Dalavuelta - 2025', 'costas'),
(3, '2024-07-28', 'Dalavuelta - 2025', 'eleven11'),
(3, '2024-08-15', 'Dalavuelta - 2025', 'jeffw'),
(2, '2024-08-02', 'Dalavuelta - 2025', 'roro'),
(2, '2025-07-20', 'Extensionismo Industrial - 2025', 'chechi'),
(2, '2025-07-18', 'Extensionismo Industrial - 2025', 'costas'),
(2, '2025-07-29', 'Extensionismo Industrial - 2025', 'eleven11'),
(2, '2025-08-05', 'Extensionismo Industrial - 2025', 'weiss'),
(2, '2010-02-25', 'Flor del Ceibo - 2010', 'chechi'),
(2, '2010-02-20', 'Flor del Ceibo - 2010', 'eleven11'),
(2, '2012-07-12', 'Flor del Ceibo - 2012', 'costas'),
(3, '2012-07-15', 'Flor del Ceibo - 2012', 'roro'),
(2, '2012-07-30', 'Flor del Ceibo - 2012', 'weiss'),
(2, '2025-03-15', 'Flor del Ceibo - 2025', 'jeffw'),
(2, '2025-03-10', 'Flor del Ceibo - 2025', 'roro'),
(1, '2026-07-18', 'Herramientas de apoyo a la enseñanza de inglés. Instalación y evaluación - 26', 'eleven11'),
(1, '2026-08-20', 'Herramientas de apoyo a la enseñanza de inglés. Instalación y evaluación - 26', 'jeffw'),
(1, '2026-06-04', 'Herramientas de apoyo a la enseñanza de inglés. Instalación y evaluación - 26', 'weiss'),
(2, '2026-02-28', 'Inclusión Energética - 2026', 'chechi'),
(3, '2026-03-03', 'Inclusión Energética - 2026', 'eleven11'),
(2, '2026-02-23', 'Inclusión Energética - 2026', 'roro'),
(3, '2026-02-25', 'Inclusión Energética - 2026', 'weiss'),
(1, '2026-07-12', 'MicroBit - 2026', 'chechi'),
(1, '2026-07-25', 'MicroBit - 2026', 'eleven11'),
(1, '2026-08-05', 'MicroBit - 2026', 'jeffw'),
(1, '2026-07-14', 'MicroBit - 2026', 'roro'),
(2, '2026-07-13', 'Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela - 2026', 'chechi'),
(2, '2026-07-22', 'Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela - 2026', 'roro'),
(2, '2026-07-20', 'Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela - 2026', 'weiss'),
(3, '2026-08-30', 'Seminarios de Resolución de Problemas - 2026', 'chechi'),
(3, '2026-07-20', 'Seminarios de Resolución de Problemas - 2026', 'costas'),
(2, '2026-08-06', 'Seminarios de Resolución de Problemas - 2026', 'roro'),
(2, '2026-07-15', 'Seminarios de Resolución de Problemas - 2026', 'weiss'),
(0, '2024-03-05', 'Taller de robótica educativa - 2024', 'chechi'),
(2, '2024-03-03', 'Taller de robótica educativa - 2024', 'eleven11'),
(3, '2024-02-20', 'Taller de robótica educativa - 2024', 'roro'),
(3, '2017-02-18', 'Taller de robótica educativa - 2024', 'weiss'),
(2, '2026-02-22', 'Taller de robótica educativa - 2026', 'costas'),
(2, '2026-02-18', 'Taller de robótica educativa - 2026', 'jeffw'),
(3, '2026-03-18', 'Taller de robótica educativa - 2026', 'roro'),
(1, '2026-08-22', 'Taller de robótica educativa - 2026-2', 'chechi'),
(1, '2026-09-03', 'Taller de robótica educativa - 2026-2', 'roro'),
(1, '2026-08-18', 'Taller de robótica educativa - 2026-2', 'weiss'),
(3, '2026-03-05', 'Talleres plenarios - 2026', 'costas'),
(2, '2026-03-07', 'Talleres plenarios - 2026', 'roro'),
(2, '2026-03-04', 'Talleres plenarios - 2026', 'weiss');

-- --------------------------------------------------------

--
-- Table structure for table `InscripcionPrograma`
--

CREATE TABLE `InscripcionPrograma` (
  `estado` int(11) NOT NULL,
  `fechaInscripcion` date NOT NULL,
  `programa_nombre` varchar(255) NOT NULL,
  `estudiante_nickname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `InscripcionPrograma`
--

INSERT INTO `InscripcionPrograma` (`estado`, `fechaInscripcion`, `programa_nombre`, `estudiante_nickname`) VALUES
(0, '2026-04-20', 'EFI Ingeniería Mecánica', 'chechi'),
(0, '2026-08-15', 'EFI Robótica', 'chechi'),
(0, '2026-07-10', 'Formación integral', 'chechi'),
(0, '2026-08-11', 'EFI Robótica', 'costas'),
(0, '2026-07-10', 'Formación integral', 'costas'),
(0, '2026-04-15', 'EFI Ingeniería Mecánica', 'eleven11'),
(0, '2026-07-12', 'Formación integral', 'eleven11'),
(0, '2026-08-30', 'EFI Robótica', 'jeffw'),
(0, '2026-08-22', 'EFI Robótica', 'roro'),
(0, '2026-07-18', 'Formación integral', 'roro'),
(0, '2026-07-15', 'Formación integral', 'weiss');

-- --------------------------------------------------------

--
-- Table structure for table `Instituto`
--

CREATE TABLE `Instituto` (
  `nombre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Instituto`
--

INSERT INTO `Instituto` (`nombre`) VALUES
('DISI'),
('Eléctrica'),
('Física'),
('IMERL'),
('IMPII'),
('INCO');

-- --------------------------------------------------------

--
-- Table structure for table `Integra`
--

CREATE TABLE `Integra` (
  `programa` varchar(255) NOT NULL,
  `curso` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Integra`
--

INSERT INTO `Integra` (`programa`, `curso`) VALUES
('EFI Ingeniería Mecánica', 'Dalavuelta'),
('EFI Ingeniería Mecánica', 'Extensionismo Industrial'),
('EFI Ingeniería Mecánica', 'Inclusión Energética'),
('Formación integral', 'Seminarios de Resolución de Problemas'),
('Formación integral', 'Extensionismo Industrial'),
('Formación integral', 'Flor del Ceibo'),
('Formación integral', 'Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela'),
('EFI Robótica', 'Taller de robótica educativa.'),
('EFI Robótica', 'MicroBit');

-- --------------------------------------------------------

--
-- Table structure for table `Organiza`
--

CREATE TABLE `Organiza` (
  `edicion` varchar(255) NOT NULL,
  `docente` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Organiza`
--

INSERT INTO `Organiza` (`edicion`, `docente`) VALUES
('Flor del Ceibo - 2010', 'bruces'),
('Flor del Ceibo - 2012', 'bruces'),
('Flor del Ceibo - 2012', 'adri'),
('Flor del Ceibo - 2025', 'bruces'),
('Flor del Ceibo - 2025', 'adri'),
('Dalavuelta - 2025', 'phils'),
('Extensionismo Industrial - 2025', 'phils'),
('Inclusión Energética - 2026', 'phils'),
('Taller de robótica educativa - 2024', 'heisenberg'),
('Taller de robótica educativa - 2026', 'heisenberg'),
('Taller de robótica educativa - 2026', 'benkenobi'),
('Taller de robótica educativa - 2026-2', 'benkenobi'),
('Taller de robótica educativa - 2026-2', 'waston'),
('Participación en investigación sobre el empleo del juego Komikan como recurso didáctico en la Escuela - 2026', 'waston'),
('Herramientas de apoyo a la enseñanza de inglés. Instalación y evaluación - 26', 'heisenberg'),
('MicroBit - 2026', 'house'),
('Talleres plenarios - 2026', 'timmy'),
('Talleres plenarios - 2026', 'danny'),
('Seminarios de Resolución de Problemas - 2026', 'timmy');

-- --------------------------------------------------------

--
-- Table structure for table `Pertenece`
--

CREATE TABLE `Pertenece` (
  `Docente_nickname` varchar(255) NOT NULL,
  `institutos_nombre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Pertenece`
--

INSERT INTO `Pertenece` (`Docente_nickname`, `institutos_nombre`) VALUES
('heisenberg', 'INCO'),
('benkenobi', 'INCO'),
('waston', 'INCO'),
('house', 'Eléctrica'),
('timmy', 'IMERL'),
('danny', 'IMERL'),
('phils', 'IMPII'),
('bruces', 'DISI'),
('adri', 'DISI');

-- --------------------------------------------------------

--
-- Table structure for table `Previas`
--

CREATE TABLE `Previas` (
  `Curso_nombre` varchar(255) NOT NULL,
  `previas_nombre` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Previas`
--

INSERT INTO `Previas` (`Curso_nombre`, `previas_nombre`) VALUES
('Seminarios de Resolución de Problemas', 'Talleres plenarios'),
('Dalavuelta', 'Talleres plenarios'),
('Extensionismo Industrial', 'Talleres plenarios');

-- --------------------------------------------------------

--
-- Table structure for table `ProgramaFormacion`
--

CREATE TABLE `ProgramaFormacion` (
  `nombre` varchar(255) NOT NULL,
  `descripcion` varchar(2000) DEFAULT NULL,
  `fechaFin` date NOT NULL,
  `fechaInicio` date NOT NULL,
  `fechaRegistro` date NOT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ProgramaFormacion`
--

INSERT INTO `ProgramaFormacion` (`nombre`, `descripcion`, `fechaFin`, `fechaInicio`, `fechaRegistro`, `imagen`) VALUES
('EFI Ingeniería Mecánica', 'Programa mecánica', '2026-10-31', '2026-05-01', '2026-01-01', 'Programa.EFI Ingeniería Mecánica.jpeg'),
('EFI Robótica', 'Programa robótica', '2026-11-18', '2026-09-03', '2026-01-01', 'Programa.EFI Robótica.jpeg'),
('Formación integral', 'Programa varios institutos', '2027-01-01', '2026-07-15', '2026-01-01', 'Programa.Formación integral.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `Usuario`
--

CREATE TABLE `Usuario` (
  `tipo_usuario` varchar(31) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `apellido` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `fNacimiento` date DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Usuario`
--

INSERT INTO `Usuario` (`tipo_usuario`, `nickname`, `apellido`, `email`, `fNacimiento`, `imagen`, `nombre`, `password`) VALUES
('DOCENTE', 'adri', 'García', 'agarcia@gmail.com', '1978-07-28', 'usr.png', 'Adriana', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('DOCENTE', 'benkenobi', 'Kenobi', 'benKenobi@gmail.com', '1914-04-02', 'benkenobi.jpg', 'Obi-Wan', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('DOCENTE', 'bruces', 'Sewell', 'sewell@gmail.com', '1959-12-03', 'usr.png', 'Bruce', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('ESTUDIANTE', 'chechi', 'Garrido', 'cgarrido@hotmail.com', '1987-09-12', 'chechi.jpeg', 'Cecilia', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('ESTUDIANTE', 'costas', 'Costas', 'gcostas@gmail.com', '1983-11-15', 'usr.png', 'Gerardo', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('DOCENTE', 'danny', 'Riccio', 'dan.riccio@gmail.com', '1963-07-05', 'usr.png', 'Daniel', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('ESTUDIANTE', 'eleven11', 'Twelve', 'eleven11@gmail.com', '1971-12-31', 'usr.png', 'Eleven', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('DOCENTE', 'heisenberg', 'White', 'heisenberg@gmail.com', '1956-03-07', 'heisenberg.png', 'Walter', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('DOCENTE', 'house', 'House', 'greghouse@gmail.com', '1959-05-15', 'house.jpeg', 'Gregory', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('ESTUDIANTE', 'jeffw', 'Williams', 'jwilliams@gmail.com', '1964-11-27', 'jeffw.jpeg', 'Jeff', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('DOCENTE', 'phils', 'Schiller', 'schiller@gmail.com', '1961-10-07', 'usr.png', 'Philip', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('ESTUDIANTE', 'roro', 'Cotelo', 'rcotelo@yahoo.com', '1975-08-02', 'roro.jpeg', 'Rodrigo', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('DOCENTE', 'timmy', 'Cook', 'tim.cook@apple.com', '1960-11-01', 'timmy.jpeg', 'Tim', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('DOCENTE', 'waston', 'Watson', 'e.watson@gmail.com', '1990-04-15', 'waston.jpg', 'Emma', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2'),
('ESTUDIANTE', 'weiss', 'Weiss', 'aweiss@hotmail.com', '1978-12-23', 'usr.png', 'Adrian', '$2a$07$Yd6WyZlyxIAWO.zScSzw5OLRZR.2KMEiNKpU3EmvvVn4vvtnwDCU2');

-- --------------------------------------------------------

--
-- Table structure for table `vinculos`
--

CREATE TABLE `vinculos` (
  `seguidor` varchar(255) NOT NULL,
  `seguido` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vinculos`
--

INSERT INTO `vinculos` (`seguidor`, `seguido`) VALUES
('eleven11', 'roro'),
('eleven11', 'heisenberg'),
('eleven11', 'waston'),
('costas', 'chechi'),
('costas', 'jeffw'),
('costas', 'benkenobi'),
('costas', 'danny'),
('costas', 'phils'),
('roro', 'costas'),
('roro', 'weiss'),
('chechi', 'eleven11'),
('chechi', 'jeffw'),
('chechi', 'house'),
('jeffw', 'eleven11'),
('weiss', 'costas'),
('weiss', 'heisenberg'),
('weiss', 'timmy'),
('heisenberg', 'roro'),
('heisenberg', 'adri'),
('benkenobi', 'danny'),
('waston', 'weiss'),
('waston', 'heisenberg'),
('house', 'jeffw'),
('house', 'weiss'),
('house', 'benkenobi'),
('timmy', 'eleven11'),
('timmy', 'chechi'),
('timmy', 'jeffw'),
('danny', 'costas'),
('danny', 'weiss'),
('danny', 'heisenberg'),
('phils', 'bruces'),
('bruces', 'phils'),
('adri', 'heisenberg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Agrupa`
--
ALTER TABLE `Agrupa`
  ADD KEY `FKe5lgia8ndmiyfd9cvgyu52bxe` (`categoria`),
  ADD KEY `FKll13cdvuh4ixmy3q40mc4hifp` (`curso`);

--
-- Indexes for table `Categoria`
--
ALTER TABLE `Categoria`
  ADD PRIMARY KEY (`nombre`);

--
-- Indexes for table `Clasifica`
--
ALTER TABLE `Clasifica`
  ADD KEY `FKf7dk8fqb03ejv86qluoh6rj73` (`categoria`),
  ADD KEY `FK1oyit9x272fb5fqphe6cuuff3` (`programa`);

--
-- Indexes for table `Curso`
--
ALTER TABLE `Curso`
  ADD PRIMARY KEY (`nombre`),
  ADD KEY `FKox7lsbhcfx01wkiyb5sajpywr` (`instituto_nombre`);

--
-- Indexes for table `Edicion`
--
ALTER TABLE `Edicion`
  ADD PRIMARY KEY (`nombre`),
  ADD KEY `FKrpbsqg2bc25nrt5obu7xkhd09` (`curso`);

--
-- Indexes for table `InscripcionEdicion`
--
ALTER TABLE `InscripcionEdicion`
  ADD PRIMARY KEY (`edicion_nombre`,`estudiante_nickname`),
  ADD KEY `FKpbxhdxqw93gdfc7vs05je7w7j` (`estudiante_nickname`);

--
-- Indexes for table `InscripcionPrograma`
--
ALTER TABLE `InscripcionPrograma`
  ADD PRIMARY KEY (`estudiante_nickname`,`programa_nombre`),
  ADD KEY `FKjtgue4wenlscps93j2p9wi8v4` (`programa_nombre`);

--
-- Indexes for table `Instituto`
--
ALTER TABLE `Instituto`
  ADD PRIMARY KEY (`nombre`);

--
-- Indexes for table `Integra`
--
ALTER TABLE `Integra`
  ADD KEY `FKa4x921dd7shhl6hwi07d979c7` (`curso`),
  ADD KEY `FK7c19elp9sp0bs3rd9wnm6jpt3` (`programa`);

--
-- Indexes for table `Organiza`
--
ALTER TABLE `Organiza`
  ADD KEY `FKr68ra9kequkodg3u7htdt9nvf` (`docente`),
  ADD KEY `FKamq1fk8ulrcm59x24fdeaygyl` (`edicion`);

--
-- Indexes for table `Pertenece`
--
ALTER TABLE `Pertenece`
  ADD KEY `FKg0hw67tch7f5gudj2ibq6hxem` (`institutos_nombre`),
  ADD KEY `FKbi78q3ryks70u07gyqgy9gydx` (`Docente_nickname`);

--
-- Indexes for table `Previas`
--
ALTER TABLE `Previas`
  ADD KEY `FKsb8ownebx9l0r5l68r4e7h30` (`previas_nombre`),
  ADD KEY `FKqwta2j6m11g1ppqoqiwih7gor` (`Curso_nombre`);

--
-- Indexes for table `ProgramaFormacion`
--
ALTER TABLE `ProgramaFormacion`
  ADD PRIMARY KEY (`nombre`);

--
-- Indexes for table `Usuario`
--
ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`nickname`),
  ADD UNIQUE KEY `UK_4tdehxj7dh8ghfc68kbwbsbll` (`email`);

--
-- Indexes for table `vinculos`
--
ALTER TABLE `vinculos`
  ADD KEY `FK1ompyta99dv6seh0fdw06m85u` (`seguido`),
  ADD KEY `FKny9von9nkm0hmw4gslshfqrxs` (`seguidor`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Agrupa`
--
ALTER TABLE `Agrupa`
  ADD CONSTRAINT `FKe5lgia8ndmiyfd9cvgyu52bxe` FOREIGN KEY (`categoria`) REFERENCES `Categoria` (`nombre`),
  ADD CONSTRAINT `FKll13cdvuh4ixmy3q40mc4hifp` FOREIGN KEY (`curso`) REFERENCES `Curso` (`nombre`);

--
-- Constraints for table `Clasifica`
--
ALTER TABLE `Clasifica`
  ADD CONSTRAINT `FK1oyit9x272fb5fqphe6cuuff3` FOREIGN KEY (`programa`) REFERENCES `ProgramaFormacion` (`nombre`),
  ADD CONSTRAINT `FKf7dk8fqb03ejv86qluoh6rj73` FOREIGN KEY (`categoria`) REFERENCES `Categoria` (`nombre`);

--
-- Constraints for table `Curso`
--
ALTER TABLE `Curso`
  ADD CONSTRAINT `FKox7lsbhcfx01wkiyb5sajpywr` FOREIGN KEY (`instituto_nombre`) REFERENCES `Instituto` (`nombre`);

--
-- Constraints for table `Edicion`
--
ALTER TABLE `Edicion`
  ADD CONSTRAINT `FKrpbsqg2bc25nrt5obu7xkhd09` FOREIGN KEY (`curso`) REFERENCES `Curso` (`nombre`);

--
-- Constraints for table `InscripcionEdicion`
--
ALTER TABLE `InscripcionEdicion`
  ADD CONSTRAINT `FK6c4otp1yimv3obppjhmav9rgi` FOREIGN KEY (`edicion_nombre`) REFERENCES `Edicion` (`nombre`),
  ADD CONSTRAINT `FKpbxhdxqw93gdfc7vs05je7w7j` FOREIGN KEY (`estudiante_nickname`) REFERENCES `Usuario` (`nickname`);

--
-- Constraints for table `InscripcionPrograma`
--
ALTER TABLE `InscripcionPrograma`
  ADD CONSTRAINT `FKb4ijbfue6fl3wygxc0yhofo5d` FOREIGN KEY (`estudiante_nickname`) REFERENCES `Usuario` (`nickname`),
  ADD CONSTRAINT `FKjtgue4wenlscps93j2p9wi8v4` FOREIGN KEY (`programa_nombre`) REFERENCES `ProgramaFormacion` (`nombre`);

--
-- Constraints for table `Integra`
--
ALTER TABLE `Integra`
  ADD CONSTRAINT `FK7c19elp9sp0bs3rd9wnm6jpt3` FOREIGN KEY (`programa`) REFERENCES `ProgramaFormacion` (`nombre`),
  ADD CONSTRAINT `FKa4x921dd7shhl6hwi07d979c7` FOREIGN KEY (`curso`) REFERENCES `Curso` (`nombre`);

--
-- Constraints for table `Organiza`
--
ALTER TABLE `Organiza`
  ADD CONSTRAINT `FKamq1fk8ulrcm59x24fdeaygyl` FOREIGN KEY (`edicion`) REFERENCES `Edicion` (`nombre`),
  ADD CONSTRAINT `FKr68ra9kequkodg3u7htdt9nvf` FOREIGN KEY (`docente`) REFERENCES `Usuario` (`nickname`);

--
-- Constraints for table `Pertenece`
--
ALTER TABLE `Pertenece`
  ADD CONSTRAINT `FKbi78q3ryks70u07gyqgy9gydx` FOREIGN KEY (`Docente_nickname`) REFERENCES `Usuario` (`nickname`),
  ADD CONSTRAINT `FKg0hw67tch7f5gudj2ibq6hxem` FOREIGN KEY (`institutos_nombre`) REFERENCES `Instituto` (`nombre`);

--
-- Constraints for table `Previas`
--
ALTER TABLE `Previas`
  ADD CONSTRAINT `FKqwta2j6m11g1ppqoqiwih7gor` FOREIGN KEY (`Curso_nombre`) REFERENCES `Curso` (`nombre`),
  ADD CONSTRAINT `FKsb8ownebx9l0r5l68r4e7h30` FOREIGN KEY (`previas_nombre`) REFERENCES `Curso` (`nombre`);

--
-- Constraints for table `vinculos`
--
ALTER TABLE `vinculos`
  ADD CONSTRAINT `FK1ompyta99dv6seh0fdw06m85u` FOREIGN KEY (`seguido`) REFERENCES `Usuario` (`nickname`),
  ADD CONSTRAINT `FKny9von9nkm0hmw4gslshfqrxs` FOREIGN KEY (`seguidor`) REFERENCES `Usuario` (`nickname`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
